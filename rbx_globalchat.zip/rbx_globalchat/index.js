const express = require("express")
const app = express()
const port = 8000
const max_chat_length = 50

let authKey = require("fs").readFileSync(require("path").join(__dirname, "/authKey.txt"))
let chat = []

console.log("AuthKey: " + authKey)

app.use(express.json())
app.use((req, res, go) => {
    if (req.query.authKey != authKey) {
        res.status(401)
        res.json({
            success: false,
            message: "Invalid Auth Key"
        })
    }
    else {
        go()
    }
})

app.get("/getchatmessages", (req, res, go) => {
    res.json({
        success: true,
        chat: chat
    })
})

app.post("/send", (req, res, go) => {
    if (req.body.message != undefined & req.body.player != undefined) {
        chat.push({
            player: req.body.player,
            message: req.body.message
        })

        if (chat.length > max_chat_length) {
            chat.shift()
        }

        res.send({
            success: true,
            message: ""
        })
    }
    else {
        res.status(400)
        res.send({
            success: false,
            message: "Malformed request body"
        })
    }
})


app.listen(port, () => {
    console.log(`Node listening on port ${port}`)
})